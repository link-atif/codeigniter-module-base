<ul>				
				<li>
					<a href="javascript:;">Students</a>
					<ul class="child-menu">
						<li><a href="<?php base_url() ?>student">Events</a></li>
						<li><a href="<?php base_url() ?>student/student_profile">Profile</a></li>
						<li><a href="<?php base_url() ?>student/history">History</a></li>
					</ul>
				</li>				
</ul>
		