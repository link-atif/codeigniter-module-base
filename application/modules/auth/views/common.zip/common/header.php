<!DOCTYPE html>
<html class="no-js"> 
<head>
	
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<title>PLEASURE - Material Design Responsive Admin Panel</title>
 
	<meta name="description" content="Pleasure is responsive, material admin dashboard panel">
	<meta name="author" content="Teamfox">

	<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
	<meta name="apple-touch-fullscreen" content="yes">
	
	<!-- BEGIN CORE CSS -->
	<link rel="stylesheet" href="<?php echo base_url();?>themes/acpe/admin/css/admin1.css">
	<link rel="stylesheet" href="<?php echo base_url();?>themes/acpe/globals/css/elements.css">
	<!-- END CORE CSS -->

	<!-- BEGIN PLUGINS CSS -->
	<link rel="stylesheet" href="<?php echo base_url();?>themes/acpe/globals/plugins/rickshaw/rickshaw.min.css">
	<link rel="stylesheet" href="<?php echo base_url();?>themes/acpe/globals/plugins/bxslider/jquery.bxslider.css">

	<link rel="stylesheet" href="<?php echo base_url();?>themes/acpe/globals/css/plugins.css">
	<!-- END PLUGINS CSS -->

	<!-- BEGIN SHORTCUT AND TOUCH ICONS -->
	<link rel="shortcut icon" href="<?php echo base_url();?>themes/acpe/globals/img/icons/favicon.ico">
	<link rel="apple-touch-icon" href="<?php echo base_url();?>themes/acpe/globals/img/icons/apple-touch-icon.png">
	<!-- END SHORTCUT AND TOUCH ICONS -->
	<script src="<?php echo base_url();?>themes/acpe/globals/plugins/modernizr/modernizr.min.js"></script>
	 <link href="<?php echo base_url();?>themes/acpe/admin/css/jquery-ui.css" rel="stylesheet">
	 <link rel="stylesheet" href="<?php echo base_url();?>themes/acpe/globals/plugins/datatables/media/css/jquery.dataTables.min.css">
       <link rel="stylesheet" href="<?php echo base_url();?>themes/acpe/globals/plugins/datatables/themes/bootstrap/dataTables.bootstrap.css">
	
</head>
<body>
	<div class="nav-bar-container">
		<!-- BEGIN ICONS -->
		<div class="nav-menu">
			<div class="hamburger">
				<span class="patty"></span>
				<span class="patty"></span>
				<span class="patty"></span>
				<span class="patty"></span>
				<span class="patty"></span>
				<span class="patty"></span>
			</div><!--.hamburger-->
		</div><!--.nav-menu-->

		<div class="nav-search">
			<span class="search"></span>
		</div><!--.nav-search-->

		<div class="nav-user">
			<div class="user">
				<img src="<?php echo base_url();?>themes/acpe/globals/img/faces/tolga-ergin.jpg" alt="">
				<span class="badge">3</span>
			</div><!--.user-->
			<div class="cross">
				<span class="line"></span>
				<span class="line"></span>
			</div><!--.cross-->
		</div><!--.nav-user-->
		<!-- END OF ICONS -->

		<div class="nav-bar-border"></div><!--.nav-bar-border-->

		<!-- BEGIN OVERLAY HELPERS -->
		<div class="overlay">
			<div class="starting-point">
				<span></span>
			</div><!--.starting-point-->
			<div class="logo">PLEASURE</div><!--.logo-->
		</div><!--.overlay-->

		<div class="overlay-secondary"></div><!--.overlay-secondary-->
		<!-- END OF OVERLAY HELPERS -->

	</div><!--.nav-bar-container-->
